import 'package:flutter/material.dart';

class CameraPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
      ),
      body: Center(
        child: Text('CAMERA',style: TextStyle(fontSize: 22),),
      ),
    );
  }

}
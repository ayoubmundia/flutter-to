import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:first_flutter_app/gallery-data.dart';

class Gallery extends StatefulWidget {
  @override
  _GalleryState createState() =>
      _GalleryState();
}

class _GalleryState extends State<Gallery> {
  String keyword =  "";
  TextEditingController editingController = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.deepPurple, title: Text('${keyword}')
      ),
      body: Column(
        children : <Widget>[
          Container(
            child: TextField(
              style: TextStyle(fontSize: 22),
              onChanged: (value){
                setState(() {
                  this.keyword = value;
                });
              },
              controller: editingController,
              decoration: InputDecoration(hintText: 'Tape a place'),
              onSubmitted: (value){
                this.keyword = value;
                Navigator.push(context, MaterialPageRoute(builder: (context) => GallerDataPage(this.keyword)));
                editingController.text="";
              },
            ),
            padding: EdgeInsets.all(10),
          ),
          Container(
            width: double.infinity,
            child: RaisedButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => GallerDataPage(keyword)));
                editingController.text="";
              },
              color: Colors.deepPurple,
              padding: EdgeInsets.all(10),
              child: Text("Search Images",style: TextStyle(fontSize: 22),),
            ),
          )
        ],
      ),
    );
  }
}
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart' ;

// ignore: must_be_immutable
class WeatherDetails extends StatefulWidget {
  String city="";
  WeatherDetails(this.city);

  @override
  _WeatherDetailsState createState() => _WeatherDetailsState();
}

class _WeatherDetailsState extends State<WeatherDetails> {
  var weatherDATA;

  @override
  void initState(){
    super.initState();
    getData(widget.city);
  }
  void getData(String city) {
    String url = "https://openweathermap.org/data/2.5/forecast?q=${city}&appid=b6907d289e10d714a6e88b30761fae22";
    http.get(url).then((resp){
      setState(() {
        this.weatherDATA = json.decode(resp.body);
      });
    }).catchError((err){
      print(err);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('Weather of city  : ${widget.city}'),
          backgroundColor: Colors.deepPurple,
      ),
      body: (weatherDATA==null ?
        Center(child: CircularProgressIndicator() ,):
        ListView.builder(
            itemCount:(weatherDATA==null?0:weatherDATA['list'].length) ,
            itemBuilder: (context, index){
              return Card(
                color: Colors.lightBlueAccent,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    CircleAvatar(
                      backgroundImage: AssetImage('images/${weatherDATA['list'][index]['weather'][0]['main'].toLowerCase()}.png'),
                    ),
                    Text("${new DateFormat('E dd/MM/yyyy').format(DateTime.fromMicrosecondsSinceEpoch(weatherDATA['list'][index]['dt']*1000000))}",
                        style: TextStyle(fontSize: 16,color: Colors.white,fontWeight:FontWeight.bold)),
                    Text("${weatherDATA['list'][index]['main']['temp'].round()} °C", style: TextStyle(fontSize: 20,color:
                    Colors.white,fontWeight:FontWeight.bold),),
                  ],
                ),
              );
            }
        )
      )
    );
  }


}
